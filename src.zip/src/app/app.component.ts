import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { SearchService } from './services/search.service';
import { BehaviorSubject, Observable } from 'rxjs';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';


@Component({
  selector: 'app-root',
  imports: [RouterOutlet, FormsModule, CommonModule ],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent {
  title = 'test202502';
  searchText: string = '';
  pageSize = 10;
  pageIndex = 0;
  searchResults$:Observable<any>;

  constructor(private searchService: SearchService,) {
    this.searchResults$ = this.searchService.getResults();
  }


  onSearch() {
    if (this.searchText.trim()) {
      this.searchService.setSearchText(this.searchText);
    }
  }

  onPageChange(index: number) {
    this.searchService.setPageIndex(index);
  }

  onPageSizeChange(size: number) {
    this.searchService.setPageSize(size);
  }
}
